module Main (main) where

import Lib

main :: IO ()
main = playGame emptyBoard Yellow
